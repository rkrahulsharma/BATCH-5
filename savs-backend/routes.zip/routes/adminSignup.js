const express = require('express');
const router = express.Router();
const db = require('../db');
const sendVerificationEmail = require('../utils/sendVerificationEmail');

router.post('/', (req, res) => {
  const { name, email, password, department } = req.body;

  const sql = `
    INSERT INTO admins (name, email, password, department)
    VALUES (?, ?, ?, ?)
  `;
  const values = [name, email, password, department];

  db.query(sql, values, async (err, result) => {
    if (err) {
      console.error('Error inserting admin data:', err);
      return res.status(500).json({ message: 'Server error' });
    }

    try {
      await sendVerificationEmail(email, name, 'Admin');
    } catch (emailErr) {
      console.error('Admin email sending error:', emailErr);
    }

    return res.status(200).json({ message: 'Admin registered successfully! Verification sent.' });
  });
});

module.exports = router;
