const express = require('express');
const router = express.Router();
const db = require('../db');

router.post('/', (req, res) => {
  const { email, password } = req.body;

  const sql = 'SELECT * FROM students WHERE email = ? AND password = ?';
  db.query(sql, [email, password], (err, results) => {
    if (err) {
      console.error("Student login error:", err);
      return res.status(500).json({ error: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    res.json({ message: 'Login successful', student: results[0] });
  });
});

module.exports = router;
