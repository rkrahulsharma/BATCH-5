const express = require('express');
const router = express.Router();
const multer = require('multer');
const db = require('../db');
const sendVerificationEmail = require('../utils/sendVerificationEmail');

// Configure multer for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = file.originalname.split('.').pop();
    cb(null, `student-${uniqueSuffix}.${ext}`);
  },
});
const upload = multer({ storage });

router.post('/', upload.single('facePhoto'), async (req, res) => {
  const {
    name,
    email,
    password,
    mobile,
    guardianName,
    guardianEmail
  } = req.body;

  if (!guardianEmail) {
    return res.status(400).json({ message: 'Guardian email is required.' });
  }

  const facePhoto = req.file ? req.file.filename : null;

  const sql = `
    INSERT INTO students 
    (name, email, password, mobile, guardian_name, guardian_email, face_photo) 
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;
  const values = [name, email, password, mobile, guardianName, guardianEmail, facePhoto];

  db.query(sql, values, async (err, result) => {
    if (err) {
      console.error('Error inserting student data:', err);
      return res.status(500).json({ message: 'Server error' });
    }

    try {
      await sendVerificationEmail(email, name, 'Student');
      await sendVerificationEmail(guardianEmail, guardianName || 'Guardian', 'Guardian');
    } catch (emailErr) {
      console.error('Email sending error:', emailErr);
    }

    return res.status(200).json({ message: 'Student registered successfully! Verification sent.' });
  });
});

module.exports = router;
