import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createMeeting } from '@videosdk.live/react-sdk';
import axios from 'axios';

const HostSession = () => {
  const navigate = useNavigate();
  const [cameraAllowed, setCameraAllowed] = useState(false);
  const [sessionId, setSessionId] = useState('');
  const [sessionName, setSessionName] = useState('');
  const [adminName, setAdminName] = useState('');
  const [intervals, setIntervals] = useState(['', '', '']);
  const [loading, setLoading] = useState(false);

  // Request camera and mic permissions
  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ video: true, audio: true })
      .then(() => setCameraAllowed(true))
      .catch(() => alert('Camera and Mic permission required to proceed.'));
  }, []);

  const handleCreateMeeting = async () => {
    setLoading(true);
    try {
      const tokenRes = await axios.get('http://localhost:5000/api/videosdk/token'); // Your backend route
      const meetingId = await createMeeting({ token: tokenRes.data.token });
      setSessionId(meetingId);
      setLoading(false);
    } catch (err) {
      alert('Failed to create session');
      setLoading(false);
    }
  };

  const handleStartSession = async () => {
    if (!sessionName || !adminName || intervals.some(val => val === '')) {
      alert('Please fill all required fields and intervals');
      return;
    }

    // Save session metadata to backend
    try {
      await axios.post('http://localhost:5000/api/session/start', {
        sessionId,
        sessionName,
        adminName,
        intervals: intervals.map(i => Number(i)), // seconds/minutes
      });

      // Redirect to meeting page
      navigate(`/admin/session/${sessionId}`);
    } catch (err) {
      alert('Failed to start session');
    }
  };

  return (
    <div className="container mt-5">
      <h3>📡 Host a New Session</h3>
      {!cameraAllowed && <p className="text-danger">Camera/Mic access required.</p>}

      <div className="card p-4 mt-3 shadow">
        <button
          className="btn btn-primary"
          disabled={loading || sessionId}
          onClick={handleCreateMeeting}
        >
          {loading ? 'Creating...' : 'Create Session'}
        </button>

        {sessionId && (
          <>
            <div className="mt-3">
              <label>Session Name</label>
              <input
                className="form-control"
                value={sessionName}
                onChange={(e) => setSessionName(e.target.value)}
              />
            </div>

            <div className="mt-3">
              <label>Admin Name</label>
              <input
                className="form-control"
                value={adminName}
                onChange={(e) => setAdminName(e.target.value)}
              />
            </div>

            <div className="mt-3">
              <label>Capture Intervals (in seconds)</label>
              {intervals.map((val, idx) => (
                <input
                  key={idx}
                  className="form-control my-2"
                  type="number"
                  min="5"
                  placeholder={`Interval ${idx + 1}`}
                  value={val}
                  onChange={(e) => {
                    const newIntervals = [...intervals];
                    newIntervals[idx] = e.target.value;
                    setIntervals(newIntervals);
                  }}
                />
              ))}
            </div>

            <button className="btn btn-success mt-3" onClick={handleStartSession}>
              Start Session
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default HostSession;
