import React from "react";

function StudentDashboard() {
  return <h2>Welcome to SAVS - StudentDash board</h2>;
}

export default StudentDashboard;
