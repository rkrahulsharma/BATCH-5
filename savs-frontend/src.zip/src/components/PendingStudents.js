const PendingStudents = ({ admin }) => {
    return <div><h4>Pending Student Approvals</h4></div>;
  };
  export default PendingStudents;