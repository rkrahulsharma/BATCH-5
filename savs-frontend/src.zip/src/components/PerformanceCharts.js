const PerformanceCharts = ({ admin }) => {
  return <div><h4>Performance Analytics (Charts)</h4></div>;
};
export default PerformanceCharts;